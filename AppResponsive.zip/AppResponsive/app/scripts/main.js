var footer= document.querySelector("#footer");
footer.innerHTML= PhysicalActivity.footer();
