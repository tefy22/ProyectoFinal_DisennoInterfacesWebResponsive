"use strict";

var footer = document.querySelector("#footer");
footer.innerHTML = PhysicalActivity.footer();
//# sourceMappingURL=main.js.map
